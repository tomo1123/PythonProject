import uuid
for i in range(20):
    print(str(uuid.uuid4()))

