# ファイル『world-lifespan.tsv』について

以下のURLより取得したExcelデータの一部を抽出したものです。

```
World health statistics 2022 > Country, WHO region and global statistics [xlsx]
[URL] https://www.who.int/data/gho/publications/world-health-statistics
[ラインセンス] CC BY-NC-SA 3.0 IGO
```

