import pandas as pd
df = pd.read_json('./your_posts_fixed.json')
print(df)
