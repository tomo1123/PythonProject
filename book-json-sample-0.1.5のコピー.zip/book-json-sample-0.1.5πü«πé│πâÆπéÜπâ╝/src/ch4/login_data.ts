interface LoginData {
    name:     string;
    link:     string;
    comments: string[];
}
type LoginDataArray = Array<LoginData>
