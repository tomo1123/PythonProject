import matplotlib.pyplot as plt 

# データを指定する
x = [1, 2, 3, 4, 5]
y = [75, 98, 83, 124, 132]

# 折れ線グラフを描画
plt.plot(x, y)
plt.show()

