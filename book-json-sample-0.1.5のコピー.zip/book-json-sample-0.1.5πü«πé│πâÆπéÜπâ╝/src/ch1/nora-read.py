import json
data = json.load(open('nora.json', 'r'))
print(data)

