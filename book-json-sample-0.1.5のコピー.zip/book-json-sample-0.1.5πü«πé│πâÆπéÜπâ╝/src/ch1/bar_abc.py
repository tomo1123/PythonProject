import matplotlib.pyplot as plt

# データを指定する
labels = ['A', 'B', 'C']
values = [30, 60, 80]

# 棒グラフを描画
plt.bar(labels, values)
plt.show()

