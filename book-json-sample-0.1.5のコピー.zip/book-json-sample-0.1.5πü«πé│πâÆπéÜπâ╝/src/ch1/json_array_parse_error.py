# エラーとなるJSON文字列の例
import json
s = "[1,2,3,]"
print(json.loads(s))

